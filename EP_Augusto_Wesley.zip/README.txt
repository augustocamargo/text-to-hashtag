0. EP_Augusto_Wesley.pdf relatório sobre o EP3.
1. Todo trabalho foi feito em Jupyter Notebook, deve-se executar os itens 2. e 3.
2. BiLSTM.jpynb é o notebook da modelagem com BiLSTM.
3. BERT.jpynb é o notebook da modelagem com BERT.
4. b2wCorpusFull.tsv é o corpus completo só que com tab como separador. 
5. Deixar o arquivo b2wCorpusFull.tsv no mesmo dir dos notebooks.
6. No BiLSTM foi usado 100% do modelo e no BERT 90%.